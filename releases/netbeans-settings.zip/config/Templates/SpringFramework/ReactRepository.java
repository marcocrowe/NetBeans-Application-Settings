<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "${project.licensePath}">

<#if package?? && package != "">
package ${package};

</#if>
import org.springframework.data.repository.reactive.${baseInterface};

public interface ${name} extends ${baseInterface}<${entityClass}, ${idClass}>
{
}
