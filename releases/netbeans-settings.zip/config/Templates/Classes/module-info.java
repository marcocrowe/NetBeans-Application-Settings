<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "${project.licensePath}">

<#if moduleName?? && moduleName != "">
module ${moduleName}
{
}
</#if>